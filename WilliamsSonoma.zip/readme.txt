Requirement: Online connectivity

Reason: I was running into a CORS error when trying to access JSON files from the filesystem so I setup 
my server to allow CORS and hosted the JSON files from there.  I have placed a copy of the JSON files used for this 
project in the /data directory

