//to prevent CORS errors using filesystem, I setup my server to allows CORS requests and hosted the JSON files.
//a copy of these files are also located in the /data folder for your reference

const productPath = "http://www.keneldridge.com/sandbox/products.json";
const productVariationPath = "http://www.keneldridge.com/sandbox/productVariations.json";

var productFunctions = {

    getProduct: function(productId, variationId) {

        //added the timer to simulate real world load times
        setTimeout(function(){ serviceFunctions.toggleSpinner(); }, 500);
        
        var ProductModel = ProductModel || {}
        //so we don't have to get the list of products each time, let's cache it
        if(serviceFunctions.hasSessionStorage())
        {
            if(serviceFunctions.getFromCache("products", "productExpiration")) {
                 ProductModel = productFunctions.filterProducts(productId, variationId,sessionStorage.getItem("products"));
                 productFunctions.bindProducts(ProductModel[0]); 

            }
            else {
                // we will set the cache to expire in 20 min
                var expiration = new Date();
                expiration.setTime(expiration.getTime() + 20*60*1000);
                serviceFunctions.setCache("productExpiration",expiration);
                serviceFunctions.getURL("GET",productPath,true,function(json) {
                    serviceFunctions.setCache("products",json);
                    ProductModel = productFunctions.filterProducts(productId, variationId,json);
                    productFunctions.bindProducts(ProductModel[0]); 
                });
            }
        }
        //if they don't have browser support, we make the trip to get it
        else {
            serviceFunctions.getURL("GET",productPath,true,function(json) {
                    ProductModel = productFunctions.filterProducts(productId, variationId,json);
                    productFunctions.bindProducts(ProductModel[0]); 
                });
        }
        productFunctions.getVariations(productId,variationId);  
        serviceFunctions.toggleSpinner(); //off
        return ProductModel;
    },

    getVariations: function (productId,variationId) {
        var ProductVariationModel = ProductVariationModel || {}
        if(serviceFunctions.hasSessionStorage())
        {
            if(serviceFunctions.getFromCache("productVariation", "productVariationExpiration")) {
                ProductVariationModel = productFunctions.filterVariations(productId,sessionStorage.getItem("productVariation"));
                productFunctions.bindProductVariations(ProductVariationModel,variationId);
            }
            else {
                // we will set the cache to expire in 60 min
                var expiration = new Date();
                expiration.setTime(expiration.getTime() + 60*60*1000);
                serviceFunctions.setCache("productVariationExpiration",expiration);
                serviceFunctions.getURL("GET",productVariationPath,true,function(json) {
                    serviceFunctions.setCache("productVariation",json);
                    ProductVariationModel = productFunctions.filterVariations(productId,json);
                    productFunctions.bindProductVariations(ProductVariationModel,variationId);
                });     
            }
        }
        //if they don't have browser support, we make the trip to get it
        else {
            ProductVariationModel = productFunctions.filterVariations(serviceFunctions.getURL("GET",productVariationPath,true));
            productFunctions.bindProductVariations(ProductVariationModel,variationId);
        }
        
        return ProductVariationModel;
    },

    filterProducts: function (productId, variationId, data) {
        var outArray = [];
        var filteredJson = JSON.parse(data).products.filter(function (row) {
            if(row.productid === productId && row.variationid ===  variationId) {
                outArray.push(row);
            } 
        });
        return outArray;
    },

    filterVariations: function (productId, data) {
        var outArray = [];
        var filteredJson = JSON.parse(data).productvariations.filter(function (row) {
            if(row.productid === productId) {
                outArray.push(row);
            } 
        });
        return outArray;
    },

    expandSection: function(obj) {

        var sections = document.getElementsByClassName("accordion");
        for(var i = 0;i< sections.length; i++) {
            //close all other panels that may be open
            if(sections[i] !== obj) {
                var panel = sections[i].nextElementSibling;
                panel.style.maxHeight = null;
                sections[i].childNodes[0].src="./assets/images/arrow-collapsed.png";
            }
        }
        obj.classList.toggle("active");
        var panel = obj.nextElementSibling;
        if(panel.style.maxHeight) {
            panel.style.maxHeight = null;
            obj.childNodes[0].src="./assets/images/arrow-collapsed.png";
        }
        else {
            panel.style.maxHeight = panel.scrollHeight + "px";
            obj.childNodes[0].src="./assets/images/arrow-expanded.png";
        }
    },

    //I didn't worry about XSS here as I assumed the JSON provider would be santizing these
    bindProducts: function (Model) {
        document.getElementById("pageTitle").innerHTML = Model.title;
        document.getElementById("productTitle").innerHTML = Model.title;
        document.getElementById("productDescription").innerHTML = Model.description;
        document.getElementById("productPrice").innerHTML = Model.price;
        document.getElementById("breadcrumbNav").innerHTML = productFunctions.displayBreadCrumb(Model);
        document.getElementById("productImage").innerHTML = "<img src='./assets/images/" + Model.imagename + "'>";
        document.getElementById("accordion").innerHTML = productFunctions.displayExpandables(Model);
    },

    bindProductVariations: function (Model,variationId) {
        var output = "";
        for(var i=0;i<Model.length;i++) {
            //add a border if it's the selected variation
            if(Model[i].variationid === variationId) {
                output += "<img style=\"border:solid 2px black\" class=\"variationImage\" onclick=\"productFunctions.getProduct('"+ Model[i].productid +"','" + Model[i].variationid  + "');\" src=\"./assets/images/"+ Model[i].imageurl +"\">";
            }
            else {
                output += "<img class=\"variationImage\" onclick=\"productFunctions.getProduct('"+ Model[i].productid +"','" + Model[i].variationid  + "');\" src=\"./assets/images/"+ Model[i].imageurl +"\">";
            }
        }
        document.getElementById("productVariations").innerHTML = output;
    },

    displayBreadCrumb : function(Model) {
        var output = "";
        var aryCrumbs = Model.breadcrumb.split('/');
        for(var i=0;i<aryCrumbs.length;i++) {
            output += "<a class='inactive' href='#'>" +  aryCrumbs[i] + "</a><span> > </span>"
        }
        output += "<a href='#' class='active'>" + Model.title + "</a>";
        return output;
    },

    qtyUp: function () {
        var textbox = document.getElementById("qty");
        textbox.value = parseInt(textbox.value) + 1;
    },

    qtyDown: function () {
        var textbox = document.getElementById("qty");
        if(parseInt(textbox.value) === 1) return;
        textbox.value = parseInt(textbox.value) - 1;
    },

    addToCart: function () {
        var qty = document.getElementById("qty");
        if(parseInt(qty.value) < 1) {
            //error handing would go here
        }
        else {
            productFunctions.toggleCartModal();
        }

    },

    toggleCartModal: function() {
        var message = document.getElementsByClassName("cart_wrap")[0];
        message.classList.toggle('hide');
    },

    displayExpandables: function(Model) {
        var output = "";
        var aryExpandables = Model.expandables;
        for(var i=0;i<aryExpandables.length;i++) {
            output += "<div class=\"accordion\" onclick=\"productFunctions.expandSection(this)\"><img src=\"./assets/images/arrow-collapsed.png\">"+ aryExpandables[i].heading +"</div><div class=\"panel\"><p>"+ aryExpandables[i].content +"</p></div>";
        }
        return output;
    }

}
