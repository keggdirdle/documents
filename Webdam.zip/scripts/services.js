serviceFunctions= {

    getUrl : function(method, url,async, callback) {
        if(!window.XMLHttpRequest)
            return;
        
        var request = new window.XMLHttpRequest();
        request.onreadystatechange = function () {
            if(request.readyState === 4 && request.status === 200) {
                var response = request.responseText;
                if(callback !== undefined) {
                    callback(response);
                }
                return response;
            }
        }
        request.open(method, url, async);
        request.send();
    },

    getImages : function (sortBy) {
        var response = serviceFunctions.getUrl("GET","./data/data.json",true, function(json,sortBy) {
            serviceFunctions.bindPage(json,sortBy)
        });
        
    },


    bindPage : function(json, sortBy) {
        var aryImages = JSON.parse(json);

        var aryImageTitles = [];
        for(var i = 0;i<aryImages.length;i++) {
            aryImageTitles.push(aryImages[i].title.toLowerCase());
        }

        aryImageTitles = aryImageTitles.sort().reverse();

        //if(sortBy !== undefined || sortBy === 'ZA') {
          //  aryImages = aryImages.sort().reverse();
           // document.getElementById().innerText = 'ZA';
        //}
        //else {
            //aryImages = aryImages.sort();
        //}
    
        var output = "";
        for(var n = 0;aryImageTitles.length;n++) {
            for(var i = 0;i<aryImages.length;i++) {
                if(aryImages[i].is_published && aryImages[i].title === aryImageTitles[n])
                    output += "<div class=\"imageBox\"><div><img src=\"./assets/images/"+ aryImages[i].image_name +"\" /></div><div class=\"boxTitle\">"+ aryImages[i].title +"</div><div class=\"boxFileName\">"+ aryImages[i].image_name +"</div><div class=\"boxLine\"></div><div class=\"boxDescription\">"+ aryImages[i].description +"</div></div>";
                }
        }
        document.getElementById("imageBoxContainer").innerHTML = output;
    }


}