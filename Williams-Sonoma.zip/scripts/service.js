var serviceFunctions = {

    getURL: function (method, url, asnyc, callback) {

        if (!window.XMLHttpRequest) 
        {
            return oldBrowserError;
        }

        var request = new XMLHttpRequest();
        request.onreadystatechange = function () {
            if (request.readyState === 4 && request.status === 200) 
            {
                var response = request.responseText;
                if(callback !== undefined)
                    callback(response);
                else
                    return response;
            }
            else //not needed, but added for better readability
                return request.responseText;      
        };
        request.open(method,url,asnyc);
        request.send();
    },

    hasSessionStorage: function() {
        return typeof Storage !== "undefined";
    },

    getFromCache: function(key, expiration) {
        if(sessionStorage.getItem(key) === null) return; 
        var expirationDate = new Date(sessionStorage.getItem(expiration));
            expirationDate.setTime(expirationDate.getTime())
        var currentdate = new Date();
            currentdate.setTime(currentdate.getTime());
        return (expirationDate > currentdate);
    },

    setCache: function(key, data) {
            sessionStorage.setItem(key,data);
            return data;
    },

    //can be used sitewide
    toggleSpinner : function() {
        var spinner = document.getElementsByClassName("loader_wrap")[0];
        spinner.classList.toggle('hide');
    }
}